import pyaudio
import wave
import time
import whisper
import os
import curses
from openai import OpenAI
from serial import Serial


alphabet_dict = {chr(65 + i): (0, 0) for i in range(26)}

alphabet_dict['A'] = (1, 20)
alphabet_dict['B'] = (5, 25)
alphabet_dict['C'] = (10, 27)
alphabet_dict['D'] = (16, 28)
alphabet_dict['E'] = (20, 30)
alphabet_dict['F'] = (27, 30)
alphabet_dict['G'] = (34, 30)
alphabet_dict['H'] = (37, 31)
alphabet_dict['I'] = (41, 31)
alphabet_dict['J'] = (44, 28)
alphabet_dict['K'] = (51, 27)
alphabet_dict['L'] = (57, 25)
alphabet_dict['M'] = (64, 22)
alphabet_dict['N'] = (0, 10)
alphabet_dict['O'] = (3, 12)
alphabet_dict['P'] = (9, 17)
alphabet_dict['Q'] = (14, 20)
alphabet_dict['R'] = (19, 22)
alphabet_dict['S'] = (24, 23)
alphabet_dict['T'] = (30, 23)
alphabet_dict['U'] = (36, 23)
alphabet_dict['V'] = (41, 21)
alphabet_dict['W'] = (47, 20)
alphabet_dict['X'] = (55, 17)
alphabet_dict['Y'] = (59, 14)
alphabet_dict['Z'] = (64, 10)
alphabet_dict['1'] = (9, 5)
alphabet_dict['2'] = (15, 5)
alphabet_dict['3'] = (19, 5)
alphabet_dict['4'] = (24, 5)
alphabet_dict['5'] = (29, 5)
alphabet_dict['6'] = (34, 5)
alphabet_dict['7'] = (39, 5)
alphabet_dict['8'] = (43, 5)
alphabet_dict['9'] = (48, 5)
alphabet_dict['0'] = (53, 5)
alphabet_dict['.'] = (24, 0)
alphabet_dict[','] = (40, 0)
alphabet_dict[' '] = (33, 13)

ser = Serial('/dev/ttyUSB0', 115200, timeout = 1)

# Audio recording parameters
FORMAT = pyaudio.paInt16  # Audio format (16-bit PCM)
CHANNELS = 2              # Number of audio channels
RATE = 22050              # Reduced sampling rate
CHUNK = 2048              # Increased buffer size
RECORD_SECONDS = 10        # Duration of recording
WAVE_OUTPUT_FILENAME = "output.wav"  # Output filename

def record_audio():
    # Initialize PyAudio
    audio = pyaudio.PyAudio()

    # Open stream
    stream = audio.open(format=FORMAT, channels=CHANNELS,
                        rate=RATE, input=True, input_device_index=2,
                        frames_per_buffer=CHUNK)

    print("Recording...")
    frames = []

    # Record for specified number of seconds
    try:
        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            try:
                data = stream.read(CHUNK)
                frames.append(data)
            except IOError as e:
                # If input overflow occurs, print an error message and continue
                if e.errno == pyaudio.paInputOverflowed:
                    print(f"Overflow at iteration {i}. Continuing...")
                    time.sleep(0.1)  # Brief pause
    except Exception as e:
        print(f"Error during recording: {e}")

    print("Recording finished.")
    stream.stop_stream()
    stream.close()
    audio.terminate()

    # Save the recorded data as a WAV file
    try:
        with wave.open(WAVE_OUTPUT_FILENAME, 'wb') as wf:
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(audio.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(frames))
    except Exception as e:
        print(f"Error saving WAV file: {e}")

def transcribe_audio(file_path):
    model = whisper.load_model("base")
    result = model.transcribe(file_path)
    return result["text"]

def move(letter):
    time.sleep(3)
    x, y = alphabet_dict[letter.upper()]
    ser.write(("g1x" + str(x) + "y" + str(y) + "f2000" + "\n").encode());
    time.sleep(3)

def call_openai_api(prompt):
    client = OpenAI(api_key='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')  # Replace with your actual API key
    completion = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant trapped in a ouija board and are a ghost."},
            {"role": "user", "content": "Answer the following query in an ominous tone and under 25 characters: " + prompt}
        ]
    )
    return completion.choices[0].message.content

def main():
    # Record audio
    record_audio()

    # Transcribe audio
    transcription = transcribe_audio(WAVE_OUTPUT_FILENAME)
    print("Transcribed: ", transcription)

    # Initialize serial connection

    # Call OpenAI API with the transcription
    response = call_openai_api(transcription)
    
    print("Response from OpenAI:\n", response)
    
    for char in response:
        move(char)
        
    t_end = time.time() + 10
    while time.time() < t_end:
        ser.write(("g1x0y0f500\n").encode());
    
if __name__ == '__main__':
    main()
