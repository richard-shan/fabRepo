import websocket
import time

def on_message(ws, message):
    with open('received_image.jpg', 'wb') as f:
        f.write(message)
    print("Received image and saved.")

def on_error(ws, error):
    print("Error:", error)

def on_close(ws, close_status_code, close_msg):
    print("### closed ###")
    print("Close status code:", close_status_code)
    print("Close message:", close_msg)

def on_open(ws):
    def run(*args):
        time.sleep(1)
        ws.send("capture")
        time.sleep(1)
        ws.close()
    import threading
    threading.Thread(target=run).start()

if __name__ == "__main__":
    websocket.enableTrace(True)
    ws = websocket.WebSocketApp("ws://10.12.28.193:81",
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
    ws.on_open = on_open
    ws.run_forever()
