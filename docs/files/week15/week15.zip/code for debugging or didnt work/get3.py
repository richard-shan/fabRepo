import requests
import os

def fetch_and_save_base64(ip_address, base64_path):
    url = f'http://{ip_address}/base64'
    print(f"Attempting to fetch image from {url}")
    
    response = requests.get(url)
    print(f"HTTP status code: {response.status_code}")
    
    if response.status_code == 200:
        print(f"Received data length: {len(response.content)} bytes")
        try:
            # Check if the SD card is writable and accessible
            try:
                with open('/sd/test.txt', 'w') as test_file:
                    test_file.write('Hello, SD!')
                print("SD card is writable.")
                os.remove('/sd/test.txt')
            except Exception as e:
                print(f"Error accessing SD card: {e}")
                return

            # Save the base64 string directly
            with open(base64_path, 'w') as file:
                file.write(response.content.decode('utf-8'))
            print(f"Base64 data saved to {base64_path}")
        except Exception as e:
            print(f"Error writing base64 data to file: {e}")
    else:
        print("Failed to retrieve image")

ip_address = '10.12.28.193'
base64_path = '/sd/downloaded_image_base64.txt'

fetch_and_save_base64(ip_address, base64_path)
