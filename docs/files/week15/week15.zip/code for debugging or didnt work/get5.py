import requests
import os
import machine
import sdcard
import uos

url = "http://10.12.28.193/base64"

# Setup SPI bus
spi = machine.SPI(0, baudrate=4000000, polarity=0, phase=0, sck=machine.Pin(18), mosi=machine.Pin(19), miso=machine.Pin(16))

# Setup SD card
sd = sdcard.SDCard(spi, machine.Pin(5))  # CS pin
vfs = os.VfsFat(sd)
uos.mount(vfs, '/sd')

response = requests.get(url)
print(response)
print(response.text)

# Test writing to a file
with open('/sd/img64.txt', 'w') as f:
    f.write(response.text)

# Test reading from a file
with open('/sd/img64.txt', 'r') as f:
    print(f.read())

# List files in the root of the SD card
print('Files on SD card:', os.listdir('/sd'))

