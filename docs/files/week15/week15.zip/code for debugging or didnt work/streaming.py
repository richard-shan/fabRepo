import network
import urequests
import ujson
import machine
import time

ssid = "CLSLabs"
password = "clshawks"

url = 'http://10.12.28.193/small'


def connect_to_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    while not wlan.isconnected():
        pass
    print('Connected to Wi-Fi')

def fetch_and_process_image(url):
    try:
        response = urequests.get(url)
        if response.status_code == 200:
            print("Image retrieved successfully")
            with open('image.jpg', 'wb') as img_file:
                img_file.write(response.content)
            print("Image saved successfully.")
        else:
            print("Failed to retrieve image. Status code:", response.status_code)
    except MemoryError:
        print("Memory error occurred!")
    finally:
        if 'response' in locals():
            response.close()

def main():
    connect_to_wifi()
    fetch_and_process_image(url)



    
if __name__ == '__main__':
    main()