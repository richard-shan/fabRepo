import requests
import base64
import os

def fetch_and_save_image(ip_address, image_path):
    url = f'http://{ip_address}/base64'
    print(f"Attempting to fetch image from {url}")
    
    response = requests.get(url)
    print(f"HTTP status code: {response.status_code}")
    
    if response.status_code == 200:
        print(f"Received data length: {len(response.content)} bytes")
        try:
            image_data = response.content
            print(f"Decoded image size: {len(image_data)} bytes")

            with open(image_path, 'wb') as file:
                file.write(image_data)
            print(f"Image saved to {image_path}")
        except Exception as e:
            print(f"Error decoding or saving the image: {e}")
    else:
        print("Failed to retrieve image")

ip_address = '10.12.28.193'
image_path = '/sd/imageInfo.txt'

fetch_and_save_image(ip_address, image_path)

