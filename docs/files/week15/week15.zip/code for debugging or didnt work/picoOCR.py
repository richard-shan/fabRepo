import network
import urequests
import ujson
import machine
import time

ssid = "CLSLabs"
password = "clshawks"

url = 'http://10.12.28.193/small'


def connect_to_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    while not wlan.isconnected():
        pass
    print('Connected to Wi-Fi')

def main():
    connect_to_wifi()
    response = urequests.get(url)
    image = response.content
    status = response.status_code
    print("done")
    print(status)


    
if __name__ == '__main__':
    main()
#     img_resp = urllib.request.urlopen(url)
#     imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
#     frame = cv2.imdecode(imgnp, -1)
# 
#     text = pytesseract.image_to_string(frame, config='--psm 6')
# 
#     print("Extracted Text:", text)
#     time.sleep(1)