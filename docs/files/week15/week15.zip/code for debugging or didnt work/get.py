import requests

def fetch_and_save_image(ip_address, image_path):
    # Construct the URL for the image
    url = f'http://{ip_address}/bmp'
    
    # Send a GET request to the URL
    response = requests.get(url)
    
    # Check if the request was successful
    if response.status_code == 200:
        # Open a file in binary write mode
        with open(image_path, 'wb') as file:
            file.write(response.content)
        print(f"Image saved to {image_path}")
    else:
        print("Failed to retrieve image")

# IP address of the camera
ip_address = '10.12.28.193'
# Local path where the image will be saved
image_path = '/sd/downloaded_image.jpg'

fetch_and_save_image(ip_address, image_path)
