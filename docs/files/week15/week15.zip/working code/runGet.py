import os
import machine
import sdcard
import uos
import network
import time

ssid = "CLSLabs"
password = "clshawks"


def connect_to_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    while not wlan.isconnected():
        pass
    print('Connected to Wi-Fi')

connect_to_wifi()

# SPI configuration
spi = machine.SPI(0, baudrate=4000000, polarity=0, phase=0, sck=machine.Pin(18), mosi=machine.Pin(19), miso=machine.Pin(16))

# SD card configuration
sd = sdcard.SDCard(spi, machine.Pin(5))  # Adjust pin according to your CS pin
uos.mount(sd, "/sd")

os.chdir("/sd")

# Execute the script
try:
    with open("get4o.py", "r") as file:
        print("Opened get")
        exec(file.read())
except OSError as e:
    print("Failed to read script from SD card:", e)

uos.umount("/sd")
