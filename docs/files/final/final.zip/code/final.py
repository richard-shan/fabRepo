from serial import Serial
import time
import requests

# OpenAI API Key
api_key = "REDACTED"

# Configure the serial port
ser = Serial('/dev/serial0', 9600, timeout = 1)

# Function to get the base64 encoded image from ESP32CAM
def get_base64_image(url):
    response = requests.get(url)
    print("Camera connected")
    return response.text

# URL to the ESP32CAM base64 image endpoint
esp32cam_url = "http://10.12.23.1/base64"

# Getting the base64 string
base64_image = get_base64_image(esp32cam_url)

# Function to send a message
def send_message(message):
    ser.write(message.encode())  # Convert the message to bytes and send
    time.sleep(1)                # Wait for a second

# Example message used for testing purposes
# testMessage = "Hello world"

def ocr():
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    # Define the information sent to GPT4o
    payload = {
        "model": "gpt-4o",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "You are a image to text OCR engine. Output the text you see in this image, and nothing else. Only use lowercase letters and no punctuation."
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"
                        }
                    }
                ]
            }
        ],
        "max_tokens": 300
    }

    # Query the engine
    response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)

    # Extract its response
    return response.json()['choices'][0]['message']['content']

try:
    message = ocr()
    send_message(message)
    print(f"Message sent: {message}")
except Exception as e:
    print(f"Error: {e}")
finally:
    ser.close()  # Close the serial port
